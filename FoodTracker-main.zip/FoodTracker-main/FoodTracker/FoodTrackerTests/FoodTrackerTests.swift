//
//  FoodTrackerTests.swift
//  FoodTrackerTests
//
//  Created by Nithusan Krishnasamymudali on 15/09/2025.
//

import Testing
import XCTest

@testable import FoodTracker

struct FoodTrackerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }
    
    

}
