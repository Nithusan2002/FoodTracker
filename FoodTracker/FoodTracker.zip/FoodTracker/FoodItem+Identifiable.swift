//
//  FoodItem+Identifiable.swift
//  FoodTracker
//
//  Created by Nithusan Krishnasamymudali on 16/09/2025.
//

import Foundation

extension FoodItem: Identifiable { }
